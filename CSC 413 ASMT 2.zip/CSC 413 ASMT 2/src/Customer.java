public class Customer {
}
