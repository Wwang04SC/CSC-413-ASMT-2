public class Transaction {
    private String Deposit;
    private String Withdrawal;
    private String Transfer;

    //Balances
    //Fees
    //Transaction Summary
}
